server = require('express')
mongo = require('mongodb')

express = server()

express.set('view engine','ejs')
express.use(server.static(__dirname+'/views'))

db = mongo.MongoClient
db.connect('mongodb://mongo:27017',(err,client) => {

  database = client.db('todos')
  let tasks = []

  express.get('/',(req,res) => {
    database.collection('tasks').find().toArray((err,result) => {
      if(err) return process.exit(1)
      tasks = result
      tasks = []
      result.forEach( e => {
        tasks.unshift(e)
      })
      console.log(tasks)

      res.render('index.ejs',{tasks:tasks})
    })
  })

  express.get('/addTodo',(req,res) => {
    database.collection('tasks').insert({task:req.query.task},(err,result) => {

      tasks.unshift({task:req.query.task})

      res.render('index.ejs',{tasks:tasks})
    })
  })

  express.listen(3000)
})

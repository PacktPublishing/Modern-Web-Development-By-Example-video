var assert = require('assert')
var http = require('http')
var votingApp = require('./app.js')

describe('when we do 2+2',function(done) {
  it('retuns 4',function() {
    assert.equal(2+2,4);
  })
})

describe('when we make a request to the server', function(done) {
  var server;
  before(function() {
    server = votingApp.listen(3000);
  })

  after(function() {
    server.close();
  })

  it('status should be 200',function(done) {
    http.get('http://127.0.0.1:3000',function(response) {
      assert.equal(response.statusCode,200);
      done();
    })
  })
})

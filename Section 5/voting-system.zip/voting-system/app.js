const server = require('express')
const mongo = require('mongodb')

const express = server()
const db = mongo.MongoClient

express.set('view engine', 'ejs')
express.use(server.static(__dirname+'/views'))

db.connect('mongodb://localhost:27017',(err,client) => {
  const database = client.db('votingsystem');

  let ssn = [];

  express.get('/',(req,res) => {
    res.render('index.ejs')
  })

  express.post('/vote',(req,res) => {
    console.log("ssn: "+req.query.ssn+" vote: "+req.query.vote);
    if(!ssn.includes(req.query.ssn)) {

      database.collection('votes').insert({vote:req.query.vote},(err,result) => {
        if(err) return process.exit(1);

        ssn.unshift(req.query.ssn)
        res.send({status:'Success',message:'Successfully Voted'});
      })
    } else {
      res.send({status:'Error',message:'Already Voted'});
    }
  })

})

express.listen(3000);
